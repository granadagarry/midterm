$('.register').click(function(){
    if($('#name').val() == ''){
        $('#name').css({'border':'1px solid red'})
    }

    $.ajax({
        url:'router/router.php?ind=register',
        data:$('#registration').serialize(),
        type:'POST',

        beforeSend:function(){
            $('#loader1').css({'display':'block'})
        },
        success:function(e){
            if(e == 'success'){

                $('#name').val('')
                $('#username').val('')
                $('#password').val('')

            }else if(e == 'username already exist'){
                
            }
            $('#loader1').css({'display':'none'})
        }
    })
})

$('.login').click(function(){
    $.ajax({
        url:'router/router.php?ind=login',
        data:$('#login').serialize(),
        type:'POST',
        
        beforeSend:function(){
            $('loader2').css({'display':'block'})
        },
        success:function(e){
            if(e == 'success'){
                
                window.location.href = "profile.php";

            }else if(e == 'Invalid Username or Password'){
                $
                
            }
            $('loader2').css({'display':'block'})
        }
    })
})